"use client";

import { useFrame } from "@react-three/fiber";
import { useRef } from "react";
import * as THREE from "three";

import KitchenStation from "./KitchenStation";
import CookingSteam from "./CookingSteam";
import KitchenDisplay from "./KitchenDisplay";
import ChefActor from "./ChefActor";

import AssetModel from "../AssetModel";
import { SCANFEAST_ASSETS } from "../../scanfeast-assets";

import type {
  OrderPhase,
} from "../../scanfeast-state";

import type {
  ScanfeastProgressRef,
} from "../CameraDirector";

function range(
  value: number,
  start: number,
  end: number,
) {
  return THREE.MathUtils.smootherstep(
    THREE.MathUtils.clamp(
      (value - start) /
      Math.max(end - start, 0.0001),
      0,
      1,
    ),
    0,
    1,
  );
}

export default function KitchenSet({
  progressRef,
  phase,
}: {
  progressRef: ScanfeastProgressRef;
  phase: OrderPhase;
}) {
  const group =
    useRef<THREE.Group>(null);

  useFrame((_, delta) => {
    if (!group.current) {
      return;
    }

    const p = progressRef.current;

    const reveal =
      range(p, 0.27, 0.39);

    const hold =
      1 -
      range(p, 0.54, 0.67);

    const visibility =
      reveal * hold;

    /*
     * Kitchen does not pop into existence.
     * It travels into the camera composition.
     */
    const targetX =
      THREE.MathUtils.lerp(
        3.35,
        0,
        reveal,
      );

    const targetY =
      THREE.MathUtils.lerp(
        -1.6,
        0,
        reveal,
      );

    const targetZ =
      THREE.MathUtils.lerp(
        -7.0,
        -4.75,
        reveal,
      );

    const targetScale =
      THREE.MathUtils.lerp(
        0.78,
        1,
        reveal,
      );

    /*
     * When the camera leaves the kitchen, it moves
     * backwards rather than snapping out.
     */
    const exitOffset =
      (1 - hold) * 2.4;

    group.current.position.x =
      THREE.MathUtils.damp(
        group.current.position.x,
        targetX,
        6.5,
        delta,
      );

    group.current.position.y =
      THREE.MathUtils.damp(
        group.current.position.y,
        targetY - exitOffset,
        6.5,
        delta,
      );

    group.current.position.z =
      THREE.MathUtils.damp(
        group.current.position.z,
        targetZ - exitOffset * 0.7,
        6.5,
        delta,
      );

    group.current.scale.setScalar(
      THREE.MathUtils.damp(
        group.current.scale.x,
        Math.max(
          0.72,
          targetScale *
          THREE.MathUtils.lerp(
            1,
            0.9,
            1 - visibility,
          ),
        ),
        6.5,
        delta,
      ),
    );

    group.current.rotation.y =
      THREE.MathUtils.damp(
        group.current.rotation.y,
        THREE.MathUtils.lerp(
          0.05,
          0,
          reveal,
        ),
        5,
        delta,
      );

    group.current.visible =
      p > 0.21 && p < 0.72;
  });

  return (
    <group
      ref={group}
      position={[3.35, -1.6, -7]}
    >
      <KitchenBackWall />

      <mesh
        position={[0, 0.72, 0.55]}
        castShadow
        receiveShadow
      >
        <boxGeometry
          args={[6.5, 0.88, 1.45]}
        />

        <meshStandardMaterial
          color="#292f36"
          roughness={0.52}
          metalness={0.15}
        />
      </mesh>

      <mesh
        position={[0, 1.22, 0.55]}
      >
        <boxGeometry
          args={[6.3, 0.07, 1.38]}
        />

        <meshStandardMaterial
          color="#979da3"
          roughness={0.3}
          metalness={0.44}
        />
      </mesh>

      <mesh
        position={[-2.9, 1.62, 0.55]}
      >
        <boxGeometry
          args={[0.05, 2.75, 0.05]}
        />

        <meshStandardMaterial
          color="#656c72"
          metalness={0.72}
          roughness={0.26}
        />
      </mesh>

      <mesh
        position={[2.9, 1.62, 0.55]}
      >
        <boxGeometry
          args={[0.05, 2.75, 0.05]}
        />

        <meshStandardMaterial
          color="#656c72"
          metalness={0.72}
          roughness={0.26}
        />
      </mesh>

      <KitchenStation
        phase={phase}
      />

      <CookingSteam
        active={
          phase === "cooking"
        }
      />

      <ChefActor
        progressRef={progressRef}
        active={
          phase === "cooking"
        }
        position={[
          -1.55,
          0,
          0.25,
        ]}
        scale={0.92}
      />

      <PrepObjects />

      <KitchenDisplay
        phase={phase}
        position={[
          1.7,
          2.42,
          -2.15,
        ]}
      />

      <pointLight
        position={[
          0,
          2.8,
          -1.7,
        ]}
        color="#ff9a5b"
        intensity={
          phase === "cooking"
            ? 1.2
            : 0.3
        }
        distance={7}
      />
    </group>
  );
}

function KitchenBackWall() {
  return (
    <mesh
      position={[0, 2.7, -2.8]}
      receiveShadow
    >
      <boxGeometry
        args={[
          7.15,
          5.45,
          0.16,
        ]}
      />

      <meshStandardMaterial
        color="#20262d"
        roughness={0.8}
      />
    </mesh>
  );
}

function PrepObjects() {
  return (
    <group
      position={[
        -1.9,
        1.28,
        0.45,
      ]}
    >
      <AssetModel
        src={
          SCANFEAST_ASSETS.cuttingBoard
        }
        scale={0.62}
      />

      <AssetModel
        src={
          SCANFEAST_ASSETS.knife
        }
        position={[
          0.23,
          0.04,
          0.08,
        ]}
        scale={0.42}
      />

      <AssetModel
        src={
          SCANFEAST_ASSETS.tomato
        }
        position={[
          -0.13,
          0.1,
          -0.09,
        ]}
        scale={0.34}
      />

      <AssetModel
        src={
          SCANFEAST_ASSETS.onion
        }
        position={[
          0.14,
          0.1,
          -0.09,
        ]}
        scale={0.34}
      />

      <AssetModel
        src={
          SCANFEAST_ASSETS.lettuce
        }
        position={[
          0.02,
          0.1,
          0.17,
        ]}
        scale={0.34}
      />
    </group>
  );
}