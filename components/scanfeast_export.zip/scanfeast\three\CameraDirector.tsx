"use client";

import { useFrame, useThree } from "@react-three/fiber";
import { useMemo, useRef } from "react";
import * as THREE from "three";

export type ScanfeastProgressRef = {
  current: number;
};

type Shot = {
  start: number;
  position: THREE.Vector3;
  lookAt: THREE.Vector3;
  fov: number;
};

const SHOTS: readonly Shot[] = [
  {
    start: 0,
    position: new THREE.Vector3(-8.6, 5.25, 11.8),
    lookAt: new THREE.Vector3(-4.3, 1.2, 2.35),
    fov: 47,
  },
  {
    start: 0.08,
    position: new THREE.Vector3(-5.9, 3.75, 9.0),
    lookAt: new THREE.Vector3(-3.2, 1.2, 2.4),
    fov: 44,
  },
  {
    start: 0.17,
    position: new THREE.Vector3(-3.8, 2.55, 6.1),
    lookAt: new THREE.Vector3(-1.55, 1.12, 1.2),
    fov: 43,
  },
  {
    start: 0.245,
    position: new THREE.Vector3(-0.85, 1.75, 3.45),
    lookAt: new THREE.Vector3(-0.15, 1.35, -0.8),
    fov: 44,
  },
  {
    start: 0.34,
    position: new THREE.Vector3(2.65, 2.0, -0.95),
    lookAt: new THREE.Vector3(3.15, 1.35, -4.2),
    fov: 43,
  },
  {
    start: 0.46,
    position: new THREE.Vector3(4.0, 2.25, -3.0),
    lookAt: new THREE.Vector3(3.55, 1.5, -4.9),
    fov: 41,
  },
  {
    start: 0.58,
    position: new THREE.Vector3(3.15, 2.25, -4.65),
    lookAt: new THREE.Vector3(3.15, 1.35, -5.2),
    fov: 40,
  },
  {
    start: 0.68,
    position: new THREE.Vector3(0.5, 3.25, -7.1),
    lookAt: new THREE.Vector3(-0.5, 2.25, -9.3),
    fov: 43,
  },
  {
    start: 0.80,
    position: new THREE.Vector3(-0.4, 4.45, -8.45),
    lookAt: new THREE.Vector3(0, 2.55, -10.55),
    fov: 44,
  },
  {
    start: 0.90,
    position: new THREE.Vector3(-0.05, 5.1, -9.15),
    lookAt: new THREE.Vector3(0, 2.65, -11.0),
    fov: 45,
  },
  {
    start: 1,
    position: new THREE.Vector3(0, 5.25, -9.35),
    lookAt: new THREE.Vector3(0, 2.7, -11.05),
    fov: 45,
  },
];

function findSegment(progress: number) {
  for (let i = 0; i < SHOTS.length - 1; i += 1) {
    const from = SHOTS[i];
    const to = SHOTS[i + 1];

    if (progress >= from.start && progress <= to.start) {
      return {
        from,
        to,
        index: i,
      };
    }
  }

  return {
    from: SHOTS[SHOTS.length - 2],
    to: SHOTS[SHOTS.length - 1],
    index: SHOTS.length - 2,
  };
}

export default function CameraDirector({
  progressRef,
}: {
  progressRef: ScanfeastProgressRef;
}) {
  // camera removed from useThree since we use state.camera inside useFrame

  const initialized = useRef(false);

  const smoothProgress = useRef(0);

  const targetPosition = useRef(new THREE.Vector3());
  const targetLookAt = useRef(new THREE.Vector3());

  const currentLookAt = useRef(new THREE.Vector3());

  const tempOffset = useMemo(
    () => new THREE.Vector3(),
    [],
  );

  useFrame((state, delta) => {
    const rawProgress = THREE.MathUtils.clamp(
      progressRef.current,
      0,
      1,
    );

    /*
     * Smooth the scroll itself.
     * This gives the camera physical inertia without
     * changing the browser's actual scroll position.
     */
    smoothProgress.current = THREE.MathUtils.damp(
      smoothProgress.current,
      rawProgress,
      6.5,
      delta,
    );

    const progress = smoothProgress.current;

    const { from, to, index } = findSegment(progress);

    const range = Math.max(
      to.start - from.start,
      0.0001,
    );

    const local = THREE.MathUtils.clamp(
      (progress - from.start) / range,
      0,
      1,
    );

    const eased = THREE.MathUtils.smootherstep(
      local,
      0,
      1,
    );

    targetPosition.current.lerpVectors(
      from.position,
      to.position,
      eased,
    );

    targetLookAt.current.lerpVectors(
      from.lookAt,
      to.lookAt,
      eased,
    );

    /*
     * Very subtle cinematic drift.
     * The effect is strongest in the middle of a shot
     * and disappears at shot boundaries.
     */
    const driftStrength =
      Math.sin(local * Math.PI) * 0.085;

    tempOffset.set(
      Math.sin(
        (progress * Math.PI * 2.0) +
        index * 0.65,
      ) * driftStrength,
      Math.sin(local * Math.PI) *
      0.035,
      0,
    );

    targetPosition.current.add(tempOffset);

    if (!initialized.current) {
      state.camera.position.copy(
        targetPosition.current,
      );

      currentLookAt.current.copy(
        targetLookAt.current,
      );

      initialized.current = true;
    }

    const positionDamping =
      1 - Math.exp(-7.25 * delta);

    const lookDamping =
      1 - Math.exp(-9.0 * delta);

    state.camera.position.lerp(
      targetPosition.current,
      positionDamping,
    );

    currentLookAt.current.lerp(
      targetLookAt.current,
      lookDamping,
    );

    state.camera.lookAt(currentLookAt.current);

    const perspectiveCamera =
      state.camera as THREE.PerspectiveCamera;

    const targetFov = THREE.MathUtils.lerp(
      from.fov,
      to.fov,
      eased,
    );

    perspectiveCamera.fov = THREE.MathUtils.damp(
      perspectiveCamera.fov,
      targetFov,
      6,
      delta,
    );

    perspectiveCamera.updateProjectionMatrix();
  });

  return null;
}