"use client";

import { useFrame } from "@react-three/fiber";
import { useRef } from "react";
import * as THREE from "three";

import type {
  ScanfeastProgressRef,
} from "../CameraDirector";

export default function SystemTransform({
  progressRef,
}: {
  progressRef: ScanfeastProgressRef;
}) {
  const group =
    useRef<THREE.Group>(null);

  const outerRing =
    useRef<THREE.Mesh>(null);

  const innerRing =
    useRef<THREE.Mesh>(null);

  const core =
    useRef<THREE.Mesh>(null);

  useFrame(({ clock }, delta) => {
    if (
      !group.current ||
      !outerRing.current ||
      !innerRing.current ||
      !core.current
    ) {
      return;
    }

    const progress =
      THREE.MathUtils.clamp(
        progressRef.current,
        0,
        1,
      );

    /*
     * Begin the transformation before the
     * architecture becomes fully visible.
     */
    const reveal =
      THREE.MathUtils.smootherstep(
        THREE.MathUtils.clamp(
          (progress - 0.76) /
            0.16,
          0,
          1,
        ),
        0,
        1,
      );

    const fade =
      1 -
      THREE.MathUtils.smootherstep(
        THREE.MathUtils.clamp(
          (progress - 0.97) /
            0.03,
          0,
          1,
        ),
        0,
        1,
      );

    const visibility =
      reveal * fade;

    group.current.visible =
      progress > 0.73;

    const targetScale =
      THREE.MathUtils.lerp(
        0.4,
        1,
        reveal,
      );

    group.current.scale.setScalar(
      THREE.MathUtils.damp(
        group.current.scale.x,
        targetScale,
        6,
        delta,
      ),
    );

    group.current.position.y =
      THREE.MathUtils.damp(
        group.current.position.y,
        THREE.MathUtils.lerp(
          -0.5,
          0,
          reveal,
        ),
        6,
        delta,
      );

    const t =
      clock.getElapsedTime();

    outerRing.current.rotation.x =
      t * 0.26;

    outerRing.current.rotation.z =
      t * 0.15;

    innerRing.current.rotation.y =
      -t * 0.34;

    innerRing.current.rotation.z =
      -t * 0.12;

    const pulse =
      1 +
      Math.sin(t * 3.5) *
        0.045;

    core.current.scale.setScalar(
      pulse,
    );

    const outerMaterial =
      outerRing.current.material as
        THREE.MeshBasicMaterial;

    const innerMaterial =
      innerRing.current.material as
        THREE.MeshBasicMaterial;

    outerMaterial.opacity =
      0.30 * visibility;

    innerMaterial.opacity =
      0.10 * visibility;
  });

  return (
    <group
      ref={group}
      position={[
        0,
        2.65,
        -9.8,
      ]}
      visible={false}
    >
      <mesh
        ref={outerRing}
        rotation={[
          0.35,
          0.5,
          0,
        ]}
      >
        <torusGeometry
          args={[
            1.35,
            0.014,
            10,
            64,
          ]}
        />

        <meshBasicMaterial
          color="#ff6a00"
          transparent
          opacity={0.3}
          depthWrite={false}
        />
      </mesh>

      <mesh
        ref={innerRing}
        rotation={[
          -0.5,
          0.2,
          0,
        ]}
      >
        <torusGeometry
          args={[
            1.0,
            0.01,
            10,
            64,
          ]}
        />

        <meshBasicMaterial
          color="#ffffff"
          transparent
          opacity={0.1}
          depthWrite={false}
        />
      </mesh>

      <mesh ref={core}>
        <icosahedronGeometry
          args={[
            0.28,
            1,
          ]}
        />

        <meshStandardMaterial
          color="#151b22"
          emissive="#ff6a00"
          emissiveIntensity={0.6}
          metalness={0.65}
          roughness={0.24}
        />
      </mesh>

      <pointLight
        color="#ff6a00"
        intensity={1.15}
        distance={3.5}
        decay={2}
      />
    </group>
  );
}
