"use client";

import {
  useAnimations,
  useGLTF,
} from "@react-three/drei";

import {
  useFrame,
} from "@react-three/fiber";

import {
  useEffect,
  useRef,
} from "react";

import * as THREE from "three";

import type {
  ScanfeastProgressRef,
} from "./CameraDirector";

type Props = {
  active: boolean;
  progressRef: ScanfeastProgressRef;
};

export default function ServerActor({
  active,
  progressRef,
}: Props) {
  const group =
    useRef<THREE.Group>(null);

  const {
    scene,
    animations,
  } = useGLTF(
    "/scanfeast/models/server.glb",
  );

  const {
    actions,
  } = useAnimations(
    animations,
    group,
  );

  const currentAction =
    useRef<
      THREE.AnimationAction | null
    >(null);

  const start =
    useRef(
      new THREE.Vector3(
        5.8,
        0,
        -5.05,
      ),
    );

  const target =
    useRef(
      new THREE.Vector3(
        3.75,
        0,
        -5.05,
      ),
    );

  useEffect(() => {
    if (!actions) {
      return;
    }

    const names =
      Object.keys(actions);

    const walkName =
      names.find((name) =>
        /walk|move|run/i.test(
          name,
        ),
      );

    const idleName =
      names.find((name) =>
        /idle|stand/i.test(
          name,
        ),
      );

    const action =
      walkName
        ? actions[walkName]
        : idleName
          ? actions[idleName]
          : actions[names[0]];

    if (!action) {
      return;
    }

    action.reset();
    action.setLoop(
      THREE.LoopRepeat,
      Infinity,
    );
    action.fadeIn(0.3);
    action.play();

    currentAction.current =
      action;

    return () => {
      action.fadeOut(0.2);
      action.stop();
    };
  }, [actions]);

  useFrame((_, delta) => {
    if (!group.current) {
      return;
    }

    const p =
      progressRef.current;

    const entrance =
      THREE.MathUtils.smootherstep(
        THREE.MathUtils.clamp(
          (p - 0.54) / 0.10,
          0,
          1,
        ),
        0,
        1,
      );

    const exit =
      THREE.MathUtils.smootherstep(
        THREE.MathUtils.clamp(
          (p - 0.66) / 0.10,
          0,
          1,
        ),
        0,
        1,
      );

    /*
     * The server follows the service path.
     */
    const travel =
      entrance *
      (1 - exit);

    const targetX =
      THREE.MathUtils.lerp(
        start.current.x,
        target.current.x,
        travel,
      );

    const targetY =
      THREE.MathUtils.lerp(
        -0.15,
        0,
        entrance,
      ) -
      exit * 0.2;

    const targetZ =
      THREE.MathUtils.lerp(
        start.current.z,
        target.current.z - 0.35,
        travel,
      ) +
      exit * 0.8;

    group.current.position.x =
      THREE.MathUtils.damp(
        group.current.position.x,
        targetX,
        4.8,
        delta,
      );

    group.current.position.y =
      THREE.MathUtils.damp(
        group.current.position.y,
        targetY,
        5.5,
        delta,
      );

    group.current.position.z =
      THREE.MathUtils.damp(
        group.current.position.z,
        targetZ,
        5.5,
        delta,
      );

    const facing =
      THREE.MathUtils.lerp(
        Math.PI * 0.5,
        Math.PI,
        travel,
      );

    group.current.rotation.y =
      THREE.MathUtils.damp(
        group.current.rotation.y,
        facing,
        5,
        delta,
      );

    const scale =
      THREE.MathUtils.lerp(
        0.82,
        0.9,
        travel,
      );

    group.current.scale.setScalar(
      scale,
    );

    group.current.visible =
      active &&
      p > 0.51 &&
      p < 0.74;

    if (currentAction.current) {
      currentAction.current.timeScale =
        THREE.MathUtils.lerp(
          0.5,
          1.0,
          travel,
        );
    }
  });

  return (
    <group
      ref={group}
      position={[
        5.8,
        0,
        -5.05,
      ]}
    >
      <primitive
        object={scene}
      />
    </group>
  );
}

useGLTF.preload(
  "/scanfeast/models/server.glb",
);