"use client";

import {
  useFrame,
} from "@react-three/fiber";

import {
  useRef,
} from "react";

import * as THREE from "three";

import type {
  OrderPhase,
} from "../../scanfeast-state";

import type {
  ScanfeastProgressRef,
} from "../CameraDirector";

function range(
  value: number,
  start: number,
  end: number,
) {
  return THREE.MathUtils.smootherstep(
    THREE.MathUtils.clamp(
      (value - start) /
      Math.max(
        end - start,
        0.0001,
      ),
      0,
      1,
    ),
    0,
    1,
  );
}

export default function ServicePass({
  progressRef,
  phase,
}: {
  progressRef: ScanfeastProgressRef;
  phase: OrderPhase;
}) {
  const glow =
    useRef<THREE.Mesh>(null);

  const light =
    useRef<THREE.PointLight>(null);

  useFrame(
    ({ clock }, delta) => {
      if (
        !glow.current ||
        !light.current
      ) {
        return;
      }

      const p =
        progressRef.current;

      const reveal =
        range(
          p,
          0.49,
          0.57,
        );

      const hold =
        1 -
        range(
          p,
          0.66,
          0.73,
        );

      const active =
        phase === "ready" ||
        (p >= 0.54 &&
          p <= 0.7);

      const visibility =
        reveal * hold;

      glow.current.visible =
        active &&
        visibility >
        0.02;

      const t =
        clock.getElapsedTime();

      const pulse =
        0.75 +
        Math.sin(
          t * 7,
        ) *
        0.18;

      glow.current.scale.setScalar(
        pulse *
        THREE.MathUtils.lerp(
          0.4,
          1,
          visibility,
        ),
      );

      const material =
        glow.current.material as
        THREE.MeshBasicMaterial;

      material.opacity =
        0.75 *
        visibility;

      light.current.intensity =
        active
          ? 0.8 *
          visibility
          : 0;

      /*
       * No invalidate() here.
       * The Canvas is continuously rendering
       * while this experience is active.
       */
      void delta;
    },
  );

  return (
    <group
      position={[
        3.15,
        0,
        -4.75,
      ]}
    >
      <mesh castShadow>
        <boxGeometry
          args={[
            5.3,
            0.95,
            0.82,
          ]}
        />

        <meshStandardMaterial
          color="#30363d"
          roughness={0.44}
          metalness={0.24}
        />
      </mesh>

      <mesh
        position={[
          0,
          0.52,
          -0.1,
        ]}
      >
        <boxGeometry
          args={[
            4.8,
            0.06,
            0.68,
          ]}
        />

        <meshStandardMaterial
          color="#92989d"
          roughness={0.3}
          metalness={0.5}
        />
      </mesh>

      <mesh
        ref={glow}
        position={[
          0,
          1.08,
          -0.15,
        ]}
      >
        <sphereGeometry
          args={[
            0.075,
            18,
            18,
          ]}
        />

        <meshBasicMaterial
          color="#ff6a00"
          transparent
          opacity={0}
        />
      </mesh>

      <pointLight
        ref={light}
        position={[
          0,
          1.08,
          -0.15,
        ]}
        color="#ff6a00"
        intensity={0}
        distance={2.4}
        decay={2}
      />

      <mesh
        position={[
          0,
          1.82,
          -0.04,
        ]}
      >
        <boxGeometry
          args={[
            3.8,
            0.035,
            0.035,
          ]}
        />

        <meshBasicMaterial
          color="#ff6a00"
          transparent
          opacity={0.24}
        />
      </mesh>
    </group>
  );
}