"use client";

import {
  Html,
} from "@react-three/drei";

import {
  useFrame,
} from "@react-three/fiber";

import {
  useRef,
} from "react";

import * as THREE from "three";

import type {
  ScanfeastProgressRef,
} from "../CameraDirector";

import OperationsDisplays from "./OperationsDisplays";

import OperationsAccess from "./OperationsAccess";

function range(
  value: number,
  start: number,
  end: number,
) {
  return THREE.MathUtils.smootherstep(
    THREE.MathUtils.clamp(
      (value - start) /
      Math.max(
        end - start,
        0.00001,
      ),
      0,
      1,
    ),
    0,
    1,
  );
}

export default function OperationsZone({
  progressRef,
}: {
  progressRef: ScanfeastProgressRef;
}) {
  const group =
    useRef<THREE.Group>(null);

  const glass =
    useRef<THREE.Mesh>(null);

  useFrame((_, delta) => {
    if (
      !group.current ||
      !glass.current
    ) {
      return;
    }

    const p =
      progressRef.current;

    const reveal =
      range(
        p,
        0.63,
        0.76,
      );

    const exit =
      range(
        p,
        0.82,
        0.92,
      );

    group.current.visible =
      p > 0.59 &&
      p < 0.94;

    group.current.position.y =
      THREE.MathUtils.damp(
        group.current.position.y,
        THREE.MathUtils.lerp(
          -0.55,
          0,
          reveal,
        ) -
        exit * 0.9,
        6,
        delta,
      );

    group.current.scale.setScalar(
      THREE.MathUtils.damp(
        group.current.scale.x,
        THREE.MathUtils.lerp(
          0.86,
          1,
          reveal,
        ),
        6,
        delta,
      ),
    );

    const material =
      glass.current.material as
      THREE.MeshPhysicalMaterial;

    material.opacity =
      THREE.MathUtils.lerp(
        0.025,
        0.085,
        reveal,
      );
  });

  return (
    <group
      ref={group}
      position={[
        -1.2,
        -0.55,
        -10.75,
      ]}
    >
      <OperationsAccess
        progressRef={
          progressRef
        }
      />

      {/* elevated platform */}
      <mesh receiveShadow>
        <boxGeometry
          args={[
            7.9,
            0.28,
            4.8,
          ]}
        />

        <meshStandardMaterial
          color="#252b31"
          roughness={0.8}
        />
      </mesh>

      {/* main desk */}
      <mesh
        position={[
          0,
          0.72,
          0.35,
        ]}
        castShadow
      >
        <boxGeometry
          args={[
            6.7,
            0.88,
            1.42,
          ]}
        />

        <meshStandardMaterial
          color="#14191f"
          roughness={0.43}
          metalness={0.25}
        />
      </mesh>

      {/* desktop */}
      <mesh
        position={[
          0,
          1.18,
          0.35,
        ]}
      >
        <boxGeometry
          args={[
            6.52,
            0.06,
            1.32,
          ]}
        />

        <meshStandardMaterial
          color="#72787d"
          roughness={0.3}
          metalness={0.46}
        />
      </mesh>

      {/* rear wall */}
      <mesh
        position={[
          0,
          2.95,
          -1.92,
        ]}
      >
        <boxGeometry
          args={[
            7.25,
            3.85,
            0.08,
          ]}
        />

        <meshStandardMaterial
          color="#11161c"
          roughness={0.72}
        />
      </mesh>

      {/* glass information wall */}
      <mesh
        ref={glass}
        position={[
          0,
          1.7,
          1.05,
        ]}
      >
        <boxGeometry
          args={[
            7.25,
            2.2,
            0.045,
          ]}
        />

        <meshPhysicalMaterial
          color="#d7e6eb"
          transparent
          opacity={0.05}
          roughness={0.08}
          transmission={0.12}
          thickness={0.04}
        />
      </mesh>

      <OperationsDisplays />

      <Html
        position={[
          0,
          3.95,
          -1.82,
        ]}
        center
        style={{
          pointerEvents:
            "none",
        }}
      >
        <div className="sf-ops-world-title">
          <span>
            06 / MANAGER OPERATIONS
          </span>

          <strong>
            LIVE RESTAURANT OVERVIEW
          </strong>

          <small>
            ORDERS · REVENUE · STATE
          </small>
        </div>
      </Html>

      {/* ambient monitor glow */}
      <pointLight
        position={[
          0,
          2.4,
          -1,
        ]}
        color="#ff6a00"
        intensity={0.45}
        distance={7}
      />
    </group>
  );
}