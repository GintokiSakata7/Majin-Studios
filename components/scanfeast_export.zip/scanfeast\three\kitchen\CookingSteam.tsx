"use client";

import {
  useFrame,
} from "@react-three/fiber";

import {
  useRef,
} from "react";

import * as THREE from "three";

export default function CookingSteam({
  active,
}: {
  active: boolean;
}) {
  const group =
    useRef<THREE.Group>(null);

  useFrame(({ clock }, delta) => {
    if (!group.current) {
      return;
    }

    const t =
      clock.getElapsedTime();

    const visibility =
      active ? 1 : 0;

    group.current.children.forEach(
      (child, index) => {
        const phase =
          index * 1.5;

        const cycle =
          (t * 0.28 +
            phase) %
          0.85;

        const y =
          1.02 + cycle;

        const x =
          Math.sin(
            t * 0.55 +
            phase,
          ) * 0.065;

        const z =
          Math.cos(
            t * 0.35 +
            phase,
          ) * 0.035;

        const scale =
          0.48 +
          Math.sin(
            t * 1.15 +
            phase,
          ) *
          0.06;

        child.position.y =
          THREE.MathUtils.damp(
            child.position.y,
            y,
            8,
            delta,
          );

        child.position.x =
          THREE.MathUtils.damp(
            child.position.x,
            x,
            8,
            delta,
          );

        child.position.z =
          THREE.MathUtils.damp(
            child.position.z,
            z,
            8,
            delta,
          );

        child.scale.setScalar(
          scale * visibility,
        );
      },
    );

    group.current.visible =
      active;
  });

  return (
    <group
      ref={group}
      visible={active}
    >
      {[0, 1, 2].map(
        (index) => (
          <mesh
            key={index}
            position={[
              0,
              1.02 +
              index *
              0.28,
              0,
            ]}
          >
            <sphereGeometry
              args={[
                0.052,
                10,
                10,
              ]}
            />

            <meshBasicMaterial
              color="#ffffff"
              transparent
              opacity={0.035}
              depthWrite={false}
            />
          </mesh>
        ),
      )}
    </group>
  );
}