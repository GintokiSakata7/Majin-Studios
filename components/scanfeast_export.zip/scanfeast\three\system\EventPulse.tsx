"use client";

import {
  useFrame,
} from "@react-three/fiber";

import {
  useRef,
} from "react";

import * as THREE from "three";

import type {
  ScanfeastProgressRef,
} from "../CameraDirector";

type Props = {
  progressRef: ScanfeastProgressRef;

  from: THREE.Vector3;
  to: THREE.Vector3;

  start: number;
  end: number;

  speed?: number;
  delay?: number;

  size?: number;
};

function smootherRange(
  value: number,
  start: number,
  end: number,
) {
  return THREE.MathUtils.smootherstep(
    THREE.MathUtils.clamp(
      (value - start) /
      Math.max(
        end - start,
        0.0001,
      ),
      0,
      1,
    ),
    0,
    1,
  );
}

export default function EventPulse({
  progressRef,
  from,
  to,
  start,
  end,
  speed = 0.3,
  delay = 0,
  size = 1,
}: Props) {
  const group =
    useRef<THREE.Group>(null);

  const core =
    useRef<THREE.Mesh>(null);

  const halo =
    useRef<THREE.Mesh>(null);

  const light =
    useRef<THREE.PointLight>(null);

  const localProgress =
    useRef(0);

  useFrame(({ clock }, delta) => {
    if (
      !group.current ||
      !core.current ||
      !halo.current ||
      !light.current
    ) {
      return;
    }

    const p =
      THREE.MathUtils.clamp(
        progressRef.current,
        0,
        1,
      );

    const reveal =
      smootherRange(
        p,
        start - 0.035,
        start + 0.015,
      );

    const exit =
      1 -
      smootherRange(
        p,
        end - 0.025,
        end + 0.035,
      );

    const visibility =
      reveal * exit;

    if (visibility <= 0.001) {
      group.current.visible =
        false;

      return;
    }

    group.current.visible =
      true;

    /*
     * The pulse travels repeatedly while this
     * portion of the system is active.
     */
    const t =
      clock.getElapsedTime();

    localProgress.current =
      (
        t * speed +
        delay
      ) % 1;

    const travel =
      localProgress.current;

    group.current.position.lerpVectors(
      from,
      to,
      travel,
    );

    const pulse =
      1 +
      Math.sin(t * 9.0) *
      0.12;

    const finalScale =
      size *
      pulse *
      THREE.MathUtils.lerp(
        0.5,
        1,
        visibility,
      );

    core.current.scale.setScalar(
      finalScale,
    );

    halo.current.scale.setScalar(
      finalScale *
      THREE.MathUtils.lerp(
        1.7,
        2.6,
        Math.sin(t * 4.5) *
        0.5 +
        0.5,
      ),
    );

    const coreMaterial =
      core.current
        .material as THREE.MeshBasicMaterial;

    const haloMaterial =
      halo.current
        .material as THREE.MeshBasicMaterial;

    coreMaterial.opacity =
      0.9 * visibility;

    haloMaterial.opacity =
      0.055 *
      visibility;

    light.current.intensity =
      0.45 *
      visibility *
      pulse;

    /*
     * Tiny forward bias makes the pulse feel like
     * a signal travelling through a system rather
     * than a floating sphere.
     */
    const travelDirection =
      new THREE.Vector3()
        .subVectors(
          to,
          from,
        )
        .normalize();

    group.current.position.add(
      travelDirection.multiplyScalar(
        0.015 *
        Math.sin(
          travel * Math.PI,
        ),
      ),
    );

    /*
     * Smoothly hide instead of popping.
     */
    group.current.scale.setScalar(
      THREE.MathUtils.damp(
        group.current.scale.x,
        visibility,
        14,
        delta,
      ),
    );
  });

  return (
    <group
      ref={group}
      visible={false}
      position={from.toArray()}
    >
      <mesh ref={core}>
        <sphereGeometry
          args={[
            0.06,
            16,
            16,
          ]}
        />

        <meshBasicMaterial
          color="#ff6a00"
          transparent
          opacity={0.9}
          depthWrite={false}
        />
      </mesh>

      <mesh ref={halo}>
        <sphereGeometry
          args={[
            0.13,
            16,
            16,
          ]}
        />

        <meshBasicMaterial
          color="#ff6a00"
          transparent
          opacity={0.055}
          depthWrite={false}
          blending={
            THREE.AdditiveBlending
          }
        />
      </mesh>

      <pointLight
        ref={light}
        color="#ff6a00"
        intensity={0}
        distance={1.4}
        decay={2}
      />
    </group>
  );
}