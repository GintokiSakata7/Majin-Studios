"use client";

import {
  useFrame,
} from "@react-three/fiber";

import {
  useRef,
} from "react";

import * as THREE from "three";

import type {
  ScanfeastProgressRef,
} from "../CameraDirector";

export default function OperationsAccess({
  progressRef,
}: {
  progressRef: ScanfeastProgressRef;
}) {
  const group =
    useRef<THREE.Group>(null);

  useFrame(() => {
    if (!group.current) {
      return;
    }

    const progress =
      progressRef.current;

    const reveal =
      THREE.MathUtils.smoothstep(
        progress,
        0.61,
        0.73,
      );

    group.current.visible =
      progress >
      0.58;

    group.current.position.y =
      THREE.MathUtils.lerp(
        -0.35,
        0,
        reveal,
      );
  });

  return (
    <group
      ref={group}
    >
      {Array.from(
        {
          length: 6,
        },
      ).map(
        (_, index) => (
          <mesh
            key={
              index
            }
            position={[
              -1.45 +
              index *
              0.42,
              0.14 +
              index *
              0.28,
              -7.1 -
              index *
              0.28,
            ]}
            castShadow
          >
            <boxGeometry
              args={[
                0.82,
                0.24,
                0.95,
              ]}
            />

            <meshStandardMaterial
              color="#30363d"
              roughness={0.52}
              metalness={0.32}
            />
          </mesh>
        ),
      )}

      {/* Hand rail */}
      <mesh
        position={[
          0.85,
          1.8,
          -8.0,
        ]}
      >
        <boxGeometry
          args={[
            0.06,
            2.8,
            0.06,
          ]}
        />

        <meshStandardMaterial
          color="#727980"
          metalness={0.82}
          roughness={0.24}
        />
      </mesh>

      <mesh
        position={[
          0.72,
          3.15,
          -8.0,
        ]}
      >
        <boxGeometry
          args={[
            0.7,
            0.05,
            0.05,
          ]}
        />

        <meshBasicMaterial
          color="#ff6a00"
          transparent
          opacity={0.6}
        />
      </mesh>
    </group>
  );
}