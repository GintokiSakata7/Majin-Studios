"use client";

import { useFrame } from "@react-three/fiber";
import { useRef } from "react";
import * as THREE from "three";

import AssetModel from "../AssetModel";
import { SCANFEAST_ASSETS } from "../../scanfeast-assets";
import type { ScanfeastProgressRef } from "../CameraDirector";

type TableProps = {
  position: [number, number, number];
  active?: boolean;
};

function ease(
  value: number,
  start: number,
  end: number,
) {
  return THREE.MathUtils.smootherstep(
    THREE.MathUtils.clamp(
      (value - start) /
      Math.max(end - start, 0.0001),
      0,
      1,
    ),
    0,
    1,
  );
}

function Table({
  position,
  active = false,
}: TableProps) {
  const group = useRef<THREE.Group>(null);

  useFrame(({ clock }) => {
    if (!group.current) {
      return;
    }

    const pulse = active
      ? 1 +
      Math.sin(
        clock.getElapsedTime() * 1.8,
      ) *
      0.008
      : 1;

    group.current.scale.set(
      pulse,
      pulse,
      pulse,
    );
  });

  return (
    <group
      ref={group}
      position={position}
    >
      <AssetModel
        src={SCANFEAST_ASSETS.table}
        scale={0.76}
        castShadow
        receiveShadow
      />

      <AssetModel
        src={SCANFEAST_ASSETS.chair}
        position={[-1.1, 0, 0]}
        rotation={[0, Math.PI / 2, 0]}
        scale={0.8}
        castShadow
      />

      <AssetModel
        src={SCANFEAST_ASSETS.chair}
        position={[1.1, 0, 0]}
        rotation={[0, -Math.PI / 2, 0]}
        scale={0.8}
        castShadow
      />

    </group>
  );
}

function DinerBackWall() {
  return (
    <group>
      <mesh
        position={[-8.0, 2.8, 2.2]}
        receiveShadow
      >
        <boxGeometry
          args={[0.14, 5.6, 9]}
        />

        <meshStandardMaterial
          color="#191f25"
          roughness={0.86}
        />
      </mesh>

      <mesh
        position={[-3.0, 5.0, 2.2]}
      >
        <boxGeometry
          args={[9.5, 0.12, 8.4]}
        />

        <meshStandardMaterial
          color="#12171d"
          roughness={0.92}
        />
      </mesh>
    </group>
  );
}

function DinerPendant({
  position,
}: {
  position: [number, number, number];
}) {
  return (
    <group position={position}>
      <mesh>
        <cylinderGeometry
          args={[
            0.018,
            0.018,
            0.8,
            8,
          ]}
        />

        <meshStandardMaterial
          color="#696f76"
          metalness={0.72}
          roughness={0.3}
        />
      </mesh>

      <mesh
        position={[0, -0.48, 0]}
      >
        <sphereGeometry
          args={[0.12, 16, 16]}
        />

        <meshStandardMaterial
          color="#d7c5b4"
          emissive="#a86a39"
          emissiveIntensity={0.25}
          roughness={0.48}
        />
      </mesh>

      <pointLight
        position={[0, -0.5, 0]}
        intensity={0.5}
        distance={3.5}
        decay={2}
        color="#ffd4ae"
      />
    </group>
  );
}

export default function DinerSet({
  progressRef,
}: {
  progressRef: ScanfeastProgressRef;
}) {
  const group = useRef<THREE.Group>(null);

  useFrame((_, delta) => {
    if (!group.current) {
      return;
    }

    const p = progressRef.current;

    /*
     * Diner is the opening environment.
     * It remains in the world throughout the
     * walkthrough, but progressively recedes as
     * the camera travels toward the kitchen.
     */
    const enter = ease(
      p,
      0,
      0.07,
    );

    const exit = ease(
      p,
      0.20,
      0.40,
    );

    const visibility =
      1 - exit;

    const targetX = THREE.MathUtils.lerp(
      -4.2,
      -5.0,
      exit,
    );

    const targetY = THREE.MathUtils.lerp(
      -0.12,
      -1.15,
      exit,
    );

    const targetScale = THREE.MathUtils.lerp(
      1,
      0.82,
      exit,
    );

    const entryLift =
      THREE.MathUtils.lerp(
        -0.32,
        0,
        enter,
      );

    group.current.position.x =
      THREE.MathUtils.damp(
        group.current.position.x,
        targetX,
        7,
        delta,
      );

    group.current.position.y =
      THREE.MathUtils.damp(
        group.current.position.y,
        entryLift + targetY + 0.12,
        7,
        delta,
      );

    group.current.scale.setScalar(
      THREE.MathUtils.damp(
        group.current.scale.x,
        targetScale,
        6,
        delta,
      ),
    );

    group.current.rotation.y =
      THREE.MathUtils.damp(
        group.current.rotation.y,
        THREE.MathUtils.lerp(
          0,
          -0.035,
          exit,
        ),
        5,
        delta,
      );

    /*
     * The group never unmounts.
     * We use visibility only once the stage has
     * completely left the composition.
     */
    group.current.visible =
      visibility > 0.015;
  });

  return (
    <group
      ref={group}
      position={[-4.2, -0.12, 2.2]}
    >
      <mesh
        position={[0, 0, 0]}
        receiveShadow
      >
        <boxGeometry
          args={[9.8, 0.22, 9]}
        />

        <meshStandardMaterial
          color="#23292f"
          roughness={0.9}
        />
      </mesh>

      <Table
        position={[0, 0, 0.3]}
        active
      />

      <Table
        position={[3.2, 0, 1.8]}
      />

      <Table
        position={[3.25, 0, -1.3]}
      />

      <Table
        position={[-2.5, 0, -1.45]}
      />

      <DinerBackWall />

      <DinerPendant
        position={[-0.2, 3.8, 0.3]}
      />

      <DinerPendant
        position={[3.1, 3.8, 1.8]}
      />

      <DinerPendant
        position={[3.15, 3.8, -1.3]}
      />

      <mesh
        position={[
          -2.85,
          0.03,
          -0.1,
        ]}
      >
        <boxGeometry
          args={[0.025, 0.018, 6.8]}
        />

        <meshBasicMaterial
          color="#ff6a00"
          transparent
          opacity={0.28}
        />
      </mesh>
    </group>
  );
}