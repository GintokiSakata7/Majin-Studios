"use client";

import { useFrame } from "@react-three/fiber";
import { useRef } from "react";
import * as THREE from "three";

import type { ScanfeastProgressRef } from "../CameraDirector";

function range(
  value: number,
  start: number,
  end: number,
) {
  return THREE.MathUtils.smootherstep(
    THREE.MathUtils.clamp(
      (value - start) /
      Math.max(end - start, 0.0001),
      0,
      1,
    ),
    0,
    1,
  );
}

export default function ServiceCorridor({
  progressRef,
}: {
  progressRef: ScanfeastProgressRef;
}) {
  const group =
    useRef<THREE.Group>(null);

  const left =
    useRef<THREE.Mesh>(null);

  const right =
    useRef<THREE.Mesh>(null);

  useFrame((_, delta) => {
    if (
      !group.current ||
      !left.current ||
      !right.current
    ) {
      return;
    }

    const p = progressRef.current;

    const entrance =
      range(p, 0.16, 0.22);

    const open =
      range(p, 0.21, 0.34);

    const exit =
      range(p, 0.36, 0.48);

    /*
     * The entire corridor subtly slides into the
     * camera's route as we approach it.
     */
    const targetX =
      THREE.MathUtils.lerp(
        -0.9,
        -0.3,
        entrance,
      );

    const targetY =
      THREE.MathUtils.lerp(
        -0.9,
        0,
        entrance,
      );

    const targetScale =
      THREE.MathUtils.lerp(
        0.94,
        1,
        entrance,
      );

    group.current.position.x =
      THREE.MathUtils.damp(
        group.current.position.x,
        targetX +
        exit * 1.4,
        7,
        delta,
      );

    group.current.position.y =
      THREE.MathUtils.damp(
        group.current.position.y,
        targetY -
        exit * 0.45,
        7,
        delta,
      );

    group.current.scale.setScalar(
      THREE.MathUtils.damp(
        group.current.scale.x,
        targetScale,
        7,
        delta,
      ),
    );

    /*
     * This is the physical "door" movement.
     */
    const leftTarget =
      THREE.MathUtils.lerp(
        -1.0,
        -1.72,
        open,
      );

    const rightTarget =
      THREE.MathUtils.lerp(
        1.0,
        1.72,
        open,
      );

    left.current.position.x =
      THREE.MathUtils.damp(
        left.current.position.x,
        leftTarget,
        8,
        delta,
      );

    right.current.position.x =
      THREE.MathUtils.damp(
        right.current.position.x,
        rightTarget,
        8,
        delta,
      );

    group.current.visible =
      p > 0.13 && p < 0.52;
  });

  return (
    <group
      ref={group}
      position={[-0.3, 0, -1.2]}
    >
      <mesh
        position={[0, -0.08, -1.8]}
        receiveShadow
      >
        <boxGeometry
          args={[3.0, 0.16, 7.2]}
        />

        <meshStandardMaterial
          color="#30373d"
          roughness={0.84}
        />
      </mesh>

      <mesh
        ref={left}
        position={[-1, 1.7, -1.8]}
        castShadow
      >
        <boxGeometry
          args={[0.11, 3.4, 7.2]}
        />

        <meshStandardMaterial
          color="#191f26"
          roughness={0.8}
        />
      </mesh>

      <mesh
        ref={right}
        position={[1, 1.7, -1.8]}
        castShadow
      >
        <boxGeometry
          args={[0.11, 3.4, 7.2]}
        />

        <meshStandardMaterial
          color="#191f26"
          roughness={0.8}
        />
      </mesh>

      <mesh
        position={[0, 0.012, -1.8]}
      >
        <boxGeometry
          args={[
            0.035,
            0.012,
            5.9,
          ]}
        />

        <meshBasicMaterial
          color="#ff6a00"
          transparent
          opacity={0.36}
        />
      </mesh>

      <mesh
        position={[0, 1.55, -4.8]}
      >
        <boxGeometry
          args={[
            0.04,
            2.35,
            0.04,
          ]}
        />

        <meshStandardMaterial
          color="#7c838a"
          metalness={0.65}
          roughness={0.26}
        />
      </mesh>

      <pointLight
        position={[0, 2.1, -3.7]}
        color="#ff6a00"
        intensity={0.65}
        distance={4}
      />
    </group>
  );
}