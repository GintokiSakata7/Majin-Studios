"use client";

import {
  Html,
} from "@react-three/drei";

type MonitorProps = {
  position: [
    number,
    number,
    number,
  ];

  title: string;
  value: string;
  detail: string;
  accent?: boolean;
};

function Monitor({
  position,
  title,
  value,
  detail,
  accent = false,
}: MonitorProps) {
  return (
    <group
      position={position}
    >
      <mesh castShadow>
        <boxGeometry
          args={[
            2.08,
            1.38,
            0.08,
          ]}
        />

        <meshStandardMaterial
          color="#090d12"
          roughness={0.18}
          metalness={0.5}
        />
      </mesh>

      <mesh
        position={[
          0,
          0,
          0.052,
        ]}
      >
        <planeGeometry
          args={[
            1.82,
            1.12,
          ]}
        />

        <meshBasicMaterial
          color="#0d141a"
        />
      </mesh>

      <mesh
        position={[
          0,
          -0.48,
          0.07,
        ]}
      >
        <boxGeometry
          args={[
            1.62,
            0.015,
            0.014,
          ]}
        />

        <meshBasicMaterial
          color={
            accent
              ? "#8ce1ad"
              : "#ff6a00"
          }
        />
      </mesh>

      <Html
        transform
        center
        position={[
          0,
          0,
          0.085,
        ]}
        distanceFactor={5.4}
        style={{
          pointerEvents:
            "none",
        }}
      >
        <div className="sf-ops-monitor">
          <span>
            {title}
          </span>

          <strong>
            {value}
          </strong>

          <small>
            {detail}
          </small>
        </div>
      </Html>
    </group>
  );
}

export default function OperationsDisplays() {
  return (
    <group>
      <Monitor
        position={[
          -2.3,
          2.05,
          -11.55,
        ]}
        title="ORDERS"
        value="24"
        detail="LIVE QUEUE"
      />

      <Monitor
        position={[
          0,
          2.05,
          -11.55,
        ]}
        title="REVENUE"
        value="₹12.4K"
        detail="TODAY"
      />

      <Monitor
        position={[
          2.3,
          2.05,
          -11.55,
        ]}
        title="SYSTEM"
        value="LIVE"
        detail="SOCKET.IO"
        accent
      />
    </group>
  );
}